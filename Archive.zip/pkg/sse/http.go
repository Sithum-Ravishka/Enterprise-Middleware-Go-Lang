// pkg/sse/handler.go
package sse

import (
	"bufio"
	"fmt"
	"net/http"
	"regexp"
	"time"
)

var idRe = regexp.MustCompile(`^[A-Za-z0-9._:-]{1,128}$`)

// Handler returns an http.Handler that streams SSE events from the Hub.
func Handler(h *Hub) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Prefer ?client_id=..., allow X-Client-Id header, and (legacy) ?trace_id=...
		clientID := r.URL.Query().Get("client_id")
		if clientID == "" {
			clientID = r.Header.Get("X-Client-Id")
		}
		if clientID == "" {
			clientID = r.URL.Query().Get("trace_id") // legacy compatibility
		}

		if clientID == "" {
			http.Error(w, "missing client_id", http.StatusBadRequest)
			return
		}
		if !idRe.MatchString(clientID) {
			http.Error(w, "invalid client_id", http.StatusBadRequest)
			return
		}

		// CORS + SSE headers
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Cache-Control", "no-cache")
		w.Header().Set("Connection", "keep-alive")
		w.Header().Set("X-Accel-Buffering", "no")

		// Make sure we can flush
		flusher, ok := w.(http.Flusher)
		if !ok {
			http.Error(w, "streaming unsupported", http.StatusInternalServerError)
			return
		}

		// Subscribe this client
		ch := h.Subscribe(clientID)
		defer h.Unsubscribe(clientID, ch)

		fmt.Println("[DEBUG] SSE subscribed client_id:", clientID)

		// Buffered writer helps with proxies; always flush after writes
		bw := bufio.NewWriter(w)
		write := func(s string) error {
			if _, err := bw.WriteString(s); err != nil {
				return err
			}
			if err := bw.Flush(); err != nil {
				return err
			}
			flusher.Flush()
			return nil
		}

		// Advise client to retry after disconnects
		_ = write("retry: 5000\n\n")

		// Send an initial comment + hello event
		_ = write(":ok\n\n")
		_ = write(fmt.Sprintf("event: hello\n"))
		_ = write(fmt.Sprintf("data: {\"client_id\":\"%s\",\"connected_at\":\"%s\"}\n\n",
			clientID, time.Now().UTC().Format(time.RFC3339Nano)))

		// Heartbeat pings keep idle connections alive across proxies
		ticker := time.NewTicker(25 * time.Second)
		defer ticker.Stop()

		ctx := r.Context()
		for {
			select {
			case <-ctx.Done():
				fmt.Println("[DEBUG] SSE closed for client_id:", clientID)
				return

			case <-ticker.C:
				// comment line is valid SSE and ignored by EventSource
				if err := write(": ping\n\n"); err != nil {
					fmt.Println("[DEBUG] SSE heartbeat write failed:", err)
					return
				}

			case msg, ok := <-ch:
				if !ok {
					// channel closed by hub
					return
				}
				// send as a default 'message' event; could also include id: if you track offsets
				if err := write("data: " + msg + "\n\n"); err != nil {
					fmt.Println("[DEBUG] SSE message write failed:", err)
					return
				}
			}
		}
	})
}
